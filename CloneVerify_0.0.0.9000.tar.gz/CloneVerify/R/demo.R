#' A stndard data set of SNP data of 3 clonal references and 65 Uknown samples that need to be identified as one of the three clones.
#'
#' I have included an example of our data called "DemoData.csv".
#' The 3 clones in this data set are (Criollo_22, Matina_1_6, Pound_7).
#'Each row in the data set represents an individual tree. The columns are:
#'
#'Chip.BC = The chip barcode the genotyping was done on.
#'
#'Well = The location of the sample on the chip
#'
#'ID = The status of the tree. Whether it is a clonal reference (Criollo_22, Matina_1_6, Pound_7) or if it the sample/tree that is an unknown( we do not know what it is a clone of). Unknowns can happen for a lot of reasons such as loss of tag information, or poorly kept maps.
#'
#'DC= A unique identifier given to each sample/tree
#'
#'Columns 5-10: Are 10 SNP marker names that are used for "offtyping" the trees. These specific markers are used for these three clones because they result in  1 = homozygote_1,  2= homozygote_2, 3= Heterozygote. So they make it really easy to tell these three clones apart.
#'
"demo"
